﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Almacen.Models;

namespace Almacen.Controllers
{
    public class VentasController : Controller
    {
        private AlmacenEntities db = new AlmacenEntities();

        public ActionResult Index()
        {
            var ventas = db.Ventas.Include(v => v.Cliente1).Include(v => v.Empleado).Include(v => v.Producto);
            return View(ventas.ToList());
        }

        public ActionResult Create()
        {
            ViewBag.Cliente = new SelectList(db.Clientes, "Nombre", "Apellido");
            ViewBag.Vendedor = new SelectList(db.Empleadoes, "Nombre", "Apellido");
            ViewBag.Productos = new SelectList(db.Productos, "Nombre", "Descripcion");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Cliente,Vendedor,Productos")] Venta venta)
        {
            if (ModelState.IsValid)
            {
                db.Ventas.Add(venta);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Cliente = new SelectList(db.Clientes, "Nombre", "Apellido", venta.Cliente);
            ViewBag.Vendedor = new SelectList(db.Empleadoes, "Nombre", "Apellido", venta.Vendedor);
            ViewBag.Productos = new SelectList(db.Productos, "Nombre", "Descripcion", venta.Productos);
            return View(venta);
        }

        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Venta venta = db.Ventas.Find(id);
            if (venta == null)
            {
                return HttpNotFound();
            }
            ViewBag.Cliente = new SelectList(db.Clientes, "Nombre", "Apellido", venta.Cliente);
            ViewBag.Vendedor = new SelectList(db.Empleadoes, "Nombre", "Apellido", venta.Vendedor);
            ViewBag.Productos = new SelectList(db.Productos, "Nombre", "Descripcion", venta.Productos);
            return View(venta);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Cliente,Vendedor,Productos")] Venta venta)
        {
            if (ModelState.IsValid)
            {
                db.Entry(venta).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Cliente = new SelectList(db.Clientes, "Nombre", "Apellido", venta.Cliente);
            ViewBag.Vendedor = new SelectList(db.Empleadoes, "Nombre", "Apellido", venta.Vendedor);
            ViewBag.Productos = new SelectList(db.Productos, "Nombre", "Descripcion", venta.Productos);
            return View(venta);
        }

        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Venta venta = db.Ventas.Find(id);
            if (venta == null)
            {
                return HttpNotFound();
            }
            return View(venta);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            Venta venta = db.Ventas.Find(id);
            db.Ventas.Remove(venta);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
