create database Almacen

USE [Almacen]
GO

CREATE TABLE Cliente(
	Nombre varchar(40) Primary key,
	Apellido varchar(40),
	Direccion varchar(40)
)

CREATE TABLE Empleado(
	Nombre varchar(40) Primary key,
	Apellido varchar(40),
	Posicion varchar(40)
)

CREATE TABLE Productos(
	Nombre varchar(40) Primary key,
	Descripcion varchar(80)
)

CREATE TABLE Venta(
	Cliente varchar(40) Primary key,
	Vendedor varchar(40),
	Productos varchar(40)
)

Alter table Venta add foreign key (Cliente) references Cliente (Nombre)
Alter table Venta add foreign key (Vendedor) references Empleado (Nombre)
Alter table Venta add foreign key (Productos) references Productos (Nombre)

SELECT * FROM Cliente
SELECT * FROM Empleado
SELECT * FROM Productos
SELECT * FROM Venta


drop table Cliente
drop table Empleado
drop table Productos
drop table Venta